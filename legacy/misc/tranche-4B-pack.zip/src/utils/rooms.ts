/**
 * Tranche 4B — simple duplicate & reorder helpers
 * Drop into: src/utils/rooms.ts
 */
import { RoomConfig } from "../types/booking";

export function duplicateRoom(rooms: RoomConfig[], id: string): RoomConfig[] {
  const idx = rooms.findIndex(r => r.id === id);
  if (idx === -1) return rooms;
  const copy: RoomConfig = JSON.parse(JSON.stringify(rooms[idx]));
  copy.id = `${copy.id}-${Math.random().toString(36).slice(2, 8)}`;
  copy.name = `${copy.name} (Copy)`;
  const next = [...rooms];
  next.splice(idx + 1, 0, copy);
  return next;
}

export function move<T>(arr: T[], from: number, to: number): T[] {
  const next = [...arr];
  const [item] = next.splice(from, 1);
  next.splice(to, 0, item);
  return next;
}
