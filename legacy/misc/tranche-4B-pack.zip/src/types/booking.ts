/**
 * Tranche 4B — core types
 * Drop into: src/types/booking.ts
 */
export type ISO = string;

export type StockMap = Record<string, number>; // e.g. { Projector: 3, LapelMic: 4 }

export type TimeRange = { start: ISO; end: ISO };

export type ExtraSelection = {
  extraId: string;
  qty: number;
};

export type RoomConstraints = {
  minDurationMin?: number;           // e.g., 60
  earliestStart?: string;            // "HH:mm"
  latestEnd?: string;                 // "HH:mm"
  minLeadMinutes?: number;           // must book at least N minutes before start
  cutoffBeforeStartMinutes?: number; // hard stop N minutes before start
  blackouts?: { start: ISO; end: ISO; reason?: string }[];
};

export type RoomConfig = {
  id: string;
  name: string;
  constraints?: RoomConstraints;
  enabledExtras?: string[];          // extraIds allowed for this room
  // keep your 4A fields here (features/images/overrides etc.)
};

export type RoomBooking = {
  roomId: string;
  time: TimeRange;
  extras: ExtraSelection[];
};

export type Venue = {
  timezone?: string; // e.g., "Europe/Dublin"
  stock: StockMap;   // venue-wide stock
};

export type ExtraMeta = {
  id: string;
  stockKey?: string; // map extra -> venue.stock key; default: id
};

export type InventoryResult = {
  ok: boolean;
  shortages: { item: string; required: number; available: number }[];
};

export type ConstraintIssue = {
  roomId: string;
  kind:
    | "MIN_DURATION"
    | "WINDOW"
    | "LEAD_TIME"
    | "CUTOFF"
    | "BLACKOUT"
    | "EXTRA_DISABLED";
  message: string;
};
