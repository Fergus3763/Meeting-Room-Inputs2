/**
 * Tranche 4B — venue-wide inventory checker
 * Drop into: src/engines/inventory.ts
 */
import { ExtraMeta, InventoryResult, RoomBooking, StockMap } from "../types/booking";

export function overlaps(aStart: string, aEnd: string, bStart: string, bEnd: string) {
  return new Date(aStart) < new Date(bEnd) && new Date(bStart) < new Date(aEnd);
}

/**
 * Simple stock aggregation for the provided bookings.
 * If you need time-awareness, filter bookings by overlap (use checkInventoryForWindow).
 */
export function checkInventory(
  venueStock: StockMap,
  roomBookings: RoomBooking[],
  extrasCatalog: ExtraMeta[]
): InventoryResult {
  const extraToStockKey = new Map<string, string>();
  extrasCatalog.forEach(e => extraToStockKey.set(e.id, e.stockKey ?? e.id));

  const allocations = new Map<string, number>();
  for (const rb of roomBookings) {
    for (const ex of rb.extras || []) {
      const key = extraToStockKey.get(ex.extraId) ?? ex.extraId;
      allocations.set(key, (allocations.get(key) ?? 0) + (ex.qty || 0));
    }
  }

  const shortages: InventoryResult["shortages"] = [];
  for (const [key, required] of allocations.entries()) {
    const available = venueStock[key] ?? 0;
    if (required > available) shortages.push({ item: key, required, available });
  }

  return { ok: shortages.length === 0, shortages };
}

export function checkInventoryForWindow(
  venueStock: StockMap,
  window: { start: string; end: string },
  allBookings: RoomBooking[],
  extrasCatalog: ExtraMeta[]
): InventoryResult {
  const candidate = allBookings.filter(b => overlaps(b.time.start, b.time.end, window.start, window.end));
  return checkInventory(venueStock, candidate, extrasCatalog);
}
