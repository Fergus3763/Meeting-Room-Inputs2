/**
 * Tranche 4B — per-room constraint checks
 * Drop into: src/engines/constraints.ts
 */
import { ConstraintIssue, RoomBooking, RoomConfig, RoomConstraints, Venue } from "../types/booking";

const getMinutes = (d: Date) => Math.floor(d.getTime() / 60000);
const durationMinutes = (a: string, b: string) => Math.max(0, (new Date(b).getTime() - new Date(a).getTime()) / 60000);

function parseHHMM(hhmm?: string) {
  if (!hhmm) return undefined;
  const [h, m] = hhmm.split(":").map(n => parseInt(n, 10));
  return h * 60 + (m || 0);
}

function minutesSinceMidnight(d: Date) {
  return d.getHours() * 60 + d.getMinutes();
}

function withinWindow(d: Date, earliest?: string, latest?: string) {
  const mins = minutesSinceMidnight(d);
  const e = parseHHMM(earliest);
  const l = parseHHMM(latest);
  if (e !== undefined && mins < e) return false;
  if (l !== undefined && mins > l) return false;
  return true;
}

function overlaps(a: { s: string; e: string }, b: { s: string; e: string }) {
  return new Date(a.s) < new Date(b.e) && new Date(b.s) < new Date(a.e);
}

export function checkRoomConstraints(
  now: Date,
  venue: Venue,
  room: RoomConfig,
  booking: RoomBooking
): ConstraintIssue[] {
  const cs: RoomConstraints = room.constraints ?? {};
  const issues: ConstraintIssue[] = [];

  const dur = durationMinutes(booking.time.start, booking.time.end);
  if (cs.minDurationMin && dur < cs.minDurationMin) {
    issues.push({
      roomId: room.id,
      kind: "MIN_DURATION",
      message: `Minimum duration is ${cs.minDurationMin} min; selected ${Math.round(dur)} min.`,
    });
  }

  const startD = new Date(booking.time.start);
  const endD = new Date(booking.time.end);

  if (!withinWindow(startD, cs.earliestStart, undefined) || !withinWindow(endD, undefined, cs.latestEnd)) {
    issues.push({
      roomId: room.id,
      kind: "WINDOW",
      message: `Allowed time window is ${cs.earliestStart ?? "00:00"}–${cs.latestEnd ?? "23:59"}.`,
    });
  }

  const minsUntilStart = (startD.getTime() - now.getTime()) / 60000;
  if (cs.minLeadMinutes !== undefined && minsUntilStart < cs.minLeadMinutes) {
    issues.push({
      roomId: room.id,
      kind: "LEAD_TIME",
      message: `Must book at least ${cs.minLeadMinutes} minutes before start.`,
    });
  }
  if (cs.cutoffBeforeStartMinutes !== undefined && minsUntilStart < cs.cutoffBeforeStartMinutes) {
    issues.push({
      roomId: room.id,
      kind: "CUTOFF",
      message: `Booking cutoff is ${cs.cutoffBeforeStartMinutes} minutes before start.`,
    });
  }

  if (cs.blackouts?.length) {
    for (const bl of cs.blackouts) {
      if (overlaps({ s: booking.time.start, e: booking.time.end }, { s: bl.start, e: bl.end })) {
        issues.push({
          roomId: room.id,
          kind: "BLACKOUT",
          message: `Blackout: ${bl.reason ?? "unavailable"} (${bl.start} → ${bl.end}).`,
        });
      }
    }
  }

  if (room.enabledExtras && booking.extras?.length) {
    for (const ex of booking.extras) {
      if (!room.enabledExtras.includes(ex.extraId) && ex.qty > 0) {
        issues.push({
          roomId: room.id,
          kind: "EXTRA_DISABLED",
          message: `Extra '${ex.extraId}' is not available for ${room.name}.`,
        });
      }
    }
  }

  return issues;
}

export function checkAllConstraints(
  now: Date,
  venue: Venue,
  roomsById: Map<string, RoomConfig>,
  bookings: RoomBooking[]
): ConstraintIssue[] {
  const out: ConstraintIssue[] = [];
  for (const b of bookings) {
    const r = roomsById.get(b.roomId);
    if (!r) continue;
    out.push(...checkRoomConstraints(now, venue, r, b));
  }
  return out;
}
