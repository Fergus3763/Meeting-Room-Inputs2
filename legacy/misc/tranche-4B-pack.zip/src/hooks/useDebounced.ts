/**
 * Tranche 4B — debounced updates to avoid typing lag
 * Drop into: src/hooks/useDebounced.ts
 */
import { useCallback, useEffect, useRef } from "react";

export function useDebouncedCallback<T extends any[]>(fn: (...args: T) => void, delay = 250) {
  const fnRef = useRef(fn);
  const tRef = useRef<number | null>(null);
  useEffect(() => { fnRef.current = fn; }, [fn]);
  return useCallback((...args: T) => {
    if (tRef.current) window.clearTimeout(tRef.current);
    tRef.current = window.setTimeout(() => fnRef.current(...args), delay);
  }, [delay]);
}
