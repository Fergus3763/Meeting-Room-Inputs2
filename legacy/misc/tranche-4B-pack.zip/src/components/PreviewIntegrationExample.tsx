/**
 * Tranche 4B — example usage inside your preview UI
 * Drop into: src/components/PreviewIntegrationExample.tsx
 * Wire into your existing page or compare against your components.
 */
import React from "react";
import { checkInventory, checkInventoryForWindow } from "../engines/inventory";
import { checkAllConstraints } from "../engines/constraints";
import { Venue, RoomConfig, RoomBooking, ExtraMeta } from "../types/booking";

export default function PreviewIntegrationExample({
  venue, rooms, draftBookings, extrasCatalog,
  onProceed,
}:{
  venue: Venue;
  rooms: RoomConfig[];
  draftBookings: RoomBooking[];
  extrasCatalog: ExtraMeta[];
  onProceed?: () => void;
}) {
  const roomsById = React.useMemo(() => new Map(rooms.map(r => [r.id, r])), [rooms]);

  const constraintIssues = React.useMemo(
    () => checkAllConstraints(new Date(), venue, roomsById, draftBookings),
    [venue, roomsById, draftBookings]
  );

  const inventory = React.useMemo(
    () => checkInventory(venue.stock, draftBookings, extrasCatalog),
    [venue.stock, draftBookings, extrasCatalog]
  );

  const canProceed = constraintIssues.length === 0 && inventory.ok;

  return (
    <div className="space-y-4">
      {!inventory.ok && (
        <div className="bg-yellow-50 border border-yellow-300 rounded p-3">
          <strong>Inventory shortages:</strong>
          <ul className="list-disc ml-5">
            {inventory.shortages.map(s => (
              <li key={s.item}>
                {s.item}: need {s.required}, have {s.available}
              </li>
            ))}
          </ul>
        </div>
      )}

      {constraintIssues.length > 0 && (
        <div className="bg-red-50 border border-red-300 rounded p-3">
          <strong>Constraint issues:</strong>
          <ul className="list-disc ml-5">
            {constraintIssues.map((i, k) => <li key={k}>{i.message}</li>)}
          </ul>
        </div>
      )}

      <button disabled={!canProceed} onClick={onProceed} className="px-3 py-2 rounded bg-blue-600 text-white disabled:opacity-50">
        Proceed
      </button>
    </div>
  );
}
